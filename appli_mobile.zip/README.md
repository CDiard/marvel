Pour lancer l'application mobile, vous devez faire "npm install" pour "npx expo start"
